#pragma once
#include <string>
#include <iostream>
#include "fecha.h"
class PersonaRegistro
{
public:
	PersonaRegistro();
	
private:
	std::string cedula;
	int bandera;
	fecha fechadeEntrada;


	
};

