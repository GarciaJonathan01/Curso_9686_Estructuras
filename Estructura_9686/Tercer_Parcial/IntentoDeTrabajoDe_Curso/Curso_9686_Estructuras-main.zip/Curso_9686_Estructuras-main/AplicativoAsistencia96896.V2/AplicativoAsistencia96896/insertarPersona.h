#pragma once

// Incluimos las librerias
#include <iostream>
#include <string>
#include <fstream>
#include "Persona.h"
using namespace std;

