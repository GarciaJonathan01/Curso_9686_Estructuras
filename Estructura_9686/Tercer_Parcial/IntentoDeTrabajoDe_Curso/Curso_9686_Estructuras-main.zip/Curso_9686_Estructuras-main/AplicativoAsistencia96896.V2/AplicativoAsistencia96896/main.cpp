#include <iostream>
#include "Aplication.h"
#include "Aplication.cpp"
#include "Persona.h"
#include "Persona.cpp"
#include "operacionesPersona.cpp"
#include "menu.cpp"
#include "registro.cpp"
#include "utils.h"
#include "listaDobleCircular.cpp"
#include "nodo.cpp"


#include "OperacionesPersona.h"
#include "listaDobleCircular.h"


	


int main()
{
	Aplication app;
	app.run();
	
	

}